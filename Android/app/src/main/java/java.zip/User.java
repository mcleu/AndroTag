/**
 * Created by Dave on 19/01/2015.
 */
public class User {

    private String name;// User name
    private short id;      // Name identifier

    public User(String username,short uid){
        this.name = username;
        this.id = id;
    }
    public String getName(){
        return this.name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public short getID(){
        return this.id;
    }
    public void setID(short id){
        this.id = id;
    }

    public void setID(String idStr){
        setID(Short.parseShort(idStr));
    }
    public String getNameFull(){
        return getName()+Integer.toHexString(getID());
    }
}
