/**
 * Created by Dave on 19/01/2015.
 */
public class Player extends GeneralPlayer {

	final static long SHIELD_DELAY = 3000;
	final static long SHIELD_RATE  = 5;
	
	private int shield;
	
	private int activeGun;
	private long lastDamage;
	
	private Gun loadout[];
	
	/** Constructor */
	public Player(User u, Team t) { self(u,t,0); }
	public Player(User u, Team t, int lives) {
		self.user = u;
		self.team = t;
		self.lives = lives;
		
		score = 0;
		kills = 0;
		deaths = 0;
		assists = 0;
		inactive = false;
		respawnTime = new Date(0);
		
		activeGun = 0;
		loadout = {Gun.lancer()};
		lastDamage = System.currentTimeMillis();
	}
	
	
	/** Standard get/set functions */
	public void setLoadout(Gun[] l){ loadout = l; }
	public void setShield(int s) { 
		shield = s;  
		fixShield();
	}
	public void modShield(int m) { setShield(getShield+m); }
	public int getShield() { return shield; }
	
	
	/** ------------------   GUN MANAGEMENT   ------------------ */
	public Gun gun() {
		return loadout[activeGun];
	}
	
	public void swap() {
		activeGun = (activeGun+1)%loadout.length
	}
	
	public void reload() {
		gun().reload();
	}
	public void reloadAll() {
		for (g : loadout)
			g.reload();
	}
	
	
	/** ------------------  DAMAGE MANAGEMENT ------------------ */
	private void fixShield(){ 
		shield = (shield<0)?0:shield;
		shield = (shield>100)?100:shield;
	}
	public void damage(int amount) {
		modShield(-amount);
		lastDamage = System.currentTimeMillis();
		
		if (shield <= 0)
			this.kill();
			
	}
	public void update(){
		// Update shield
		long timeSinceLastDamage = System.currentTimeMillis()-lastDamage
		
		if (shield <100 && timeSinceLastDamage >= SHIELD_DELAY)
			modShield(SHIELD_RATE*(timeSinceLastDamage - SHIELD_DELAY));
			
	}
	
	
	
	

}
