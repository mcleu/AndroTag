/**
 * Created by Dave on 19/01/2015.
 */
public class GeneralPlayer {

	private int score;
	private int kills;
	private int deaths;
	private int assists;
	private int lives;
	private boolean inactive;
	private int id;
	private boolean onTeam;
	
	private Date respawnTime;
	
	public TeamInfo team;
	public User user;
	
	/** Constructor */
	public GeneralPlayer(User u, Team t) { self(u,t,0); }
	public GeneralPlayer(User u, Team t, int lives) {
		self.user = u;
		self.team = t;
		self.lives = lives;
		
		score = 0;
		kills = 0;
		deaths = 0;
		assists = 0;
		inactive = false;
		onTeam = false;
		respawnTime = new Date(0);
	}
	
	/** General setting and getting functions */
	public int getScore(){ return score; }
	public int getKills(){ return kills; }
	public int getDeaths(){ return deaths; }
	public int getAssists(){ return assists; }
	public int getLives() { return lives; }
	public int getID() { return id; }
	
	public void modifyScore(int m){ score+=m; }
	public void modifyKills(int m){ kills+=m; }
	public void modifyDeaths(int m) { deaths+=m; }
	public void modifyAssists(int m) { assists+=m; }
	public void modifyLives(int m) { lives+=m; }
	
	public void setScore(int m) { score = m; }
	public void setLives(int m) { lives = m; }
	public void setID (int m) { id = m; }
	
	public void setActive() { inactive = false; }
	public void setInactive() { inactive = true; }
	
	public boolean hasTeam(){ return onTeam; }
	public TeamInfo getTeam() { return team; }
	public boolean quitTeam() {
		onTeam = false;
		team = null;
	}
	public boolean setTeam(TeamInfo t) {
		if (!t.hasSlot())
			return false;
			
		if (hasTeam())
			getTeam().kick(this);
		
		t.add(this);
		
		onTeam = true;		
	}
	
	
	/** API functions */
	// Checks if a player is dead based on their respawn time
	public boolean isDead() {
		Date currentTime = new Date();
		return currentTime.after(respawnTime);
	}
	// Kills a player given the specified milliseconds dead
	public void kill(long millisDead){
		Date currentTime = new Date();
		respawnTime = new Date(currentTime.getTime() + millisDead);
	
	}
	public void kill(Date respawnDate){
		respawnTime = new Date(respawnDate);
	
	}
	
	




}
